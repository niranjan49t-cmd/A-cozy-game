package com.archa.purpleadventure

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import kotlin.math.hypot
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.requestFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.statusBarColor = Color.rgb(12, 7, 22)
        window.navigationBarColor = Color.rgb(12, 7, 22)
        setContentView(GameView())
    }
}

private data class Memory(val x: Float, val y: Float, val title: String, val body: String, var found: Boolean = false)

private class GameView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var vw = 1f
    private var vh = 1f
    private var px = 0.5f
    private var py = 0.66f
    private var speed = 0.014f
    private var dx = 0f
    private var dy = 0f
    private var pulse = 0f
    private var foundCount = 0
    private var dialog: Memory? = null
    private var showEnding = false
    private var moveTouch = false
    private var moveX = 0f
    private var moveY = 0f
    private var interactRect = RectF()
    private var upRect = RectF()
    private var downRect = RectF()
    private var leftRect = RectF()
    private var rightRect = RectF()
    private val stars = List(85) { Random.nextFloat() to Random.nextFloat() }
    private val memories = mutableListOf(
        Memory(.25f, .34f, "May 20 — Where it began", "It started with a Discord message on May 20. I had no idea that a random night could become one of the most important beginnings in my life. Somehow, out of all the people in the world, I got to meet you."),
        Memory(.74f, .30f, "The first time I saw you", "Then school made you real in a way a screen never could. I remember seeing you and feeling like my heart forgot what it was supposed to do. You were no longer just a name lighting up my phone. You were right there."),
        Memory(.73f, .70f, "The canteen", "I keep little moments that might look ordinary to anyone else. The canteen, you coming over to me, the tiny things you do without realizing they stay in my head. I collect them because they are ours."),
        Memory(.27f, .76f, "The pen", "You gave me a pen, and it became more than a pen in my memory. It reminds me that love is often hiding in small things: a gesture, a look, a moment that neither of us knew would matter this much later.")
    )

    init { isFocusable = true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        vw = width.toFloat().coerceAtLeast(1f); vh = height.toFloat().coerceAtLeast(1f)
        canvas.drawColor(Color.rgb(13, 7, 25))
        // Purple night gradient-like horizontal bands
        for (i in 0..18) {
            val t = i / 18f
            paint.color = Color.rgb((18 + 15*t).toInt(), (8 + 8*t).toInt(), (31 + 28*t).toInt())
            canvas.drawRect(0f, vh*t, vw, vh*(t+1f/18f+0.01f), paint)
        }
        // Tiny stars
        stars.forEachIndexed { i, pair ->
            paint.color = Color.argb(100 + (i % 5)*25, 231, 211, 255)
            canvas.drawCircle(pair.first*vw, pair.second*vh, 1.1f + (i%3)*.45f, paint)
        }
        // Moon
        paint.setShadowLayer(22f, 0f, 0f, Color.rgb(191, 153, 255))
        paint.color = Color.rgb(232, 219, 255)
        canvas.drawCircle(vw*.82f, vh*.13f, vw*.075f, paint)
        paint.clearShadowLayer()
        paint.color = Color.rgb(155, 127, 190)
        canvas.drawCircle(vw*.84f, vh*.115f, vw*.067f, paint)
        // Winding garden path
        paint.color = Color.rgb(57, 39, 79)
        val path = android.graphics.Path().apply {
            moveTo(vw*.5f, vh*.48f)
            cubicTo(vw*.25f, vh*.50f, vw*.25f, vh*.62f, vw*.5f, vh*.66f)
            cubicTo(vw*.80f, vh*.72f, vw*.75f, vh*.82f, vw*.5f, vh*.91f)
        }
        paint.style = Paint.Style.STROKE; paint.strokeWidth = vw*.20f; paint.strokeCap = Paint.Cap.ROUND
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.FILL
        // Glowing lamps
        listOf(.18f to .48f, .43f to .55f, .78f to .54f, .84f to .78f, .5f to .9f).forEach { (x,y) ->
            paint.setShadowLayer(18f,0f,0f,Color.rgb(222,180,255))
            paint.color = Color.rgb(242,218,255)
            canvas.drawCircle(vw*x, vh*y, vw*.012f, paint)
            paint.clearShadowLayer()
            paint.color = Color.rgb(96,68,120)
            canvas.drawRect(vw*x-vw*.004f, vh*y, vw*x+vw*.004f, vh*y+vh*.035f, paint)
        }
        // Trees / bushes around the garden edges
        for (i in 0..34) {
            val x = ((i*73)%97)/100f*vw
            val y = ((i*41+7)%91)/100f*vh
            if (x in (vw*.18f)..(vw*.82f) && y in (vh*.2f)..(vh*.92f)) continue
            paint.color = if(i%2==0) Color.rgb(43,29,64) else Color.rgb(52,34,75)
            canvas.drawCircle(x,y,vw*(.018f+(i%4)*.004f),paint)
        }
        // Memories
        memories.forEachIndexed { i,m ->
            if (!m.found) {
                val x=m.x*vw; val y=m.y*vh
                paint.setShadowLayer(18f,0f,0f,Color.rgb(214,160,255))
                paint.color=Color.rgb(240,218,255)
                canvas.drawCircle(x,y,vw*(.018f + (kotlin.math.sin(pulse+i)*.003f)),paint)
                paint.clearShadowLayer()
                paint.color=Color.rgb(131,82,190)
                canvas.drawCircle(x,y,vw*.008f,paint)
                paint.color=Color.rgb(239,220,255); paint.textAlign=Paint.Align.CENTER; paint.textSize=vw*.032f
                canvas.drawText("✦",x,y+vw*.011f,paint)
            }
        }
        // Player shadow and cute simple character
        paint.color=Color.argb(100,0,0,0);canvas.drawOval(vw*px-vw*.025f,vh*py+vh*.008f,vw*px+vw*.025f,vh*py+vh*.045f,paint)
        paint.color=Color.rgb(184,143,245);canvas.drawRoundRect(vw*px-vw*.023f,vh*py-vh*.018f,vw*px+vw*.023f,vh*py+vh*.036f,vw*.02f,vw*.02f,paint)
        paint.color=Color.rgb(247,231,255);canvas.drawCircle(vw*px,vh*py-vh*.027f,vw*.022f,paint)
        paint.color=Color.rgb(71,43,94);canvas.drawArc(vw*px-vw*.023f,vh*py-vh*.05f,vw*px+vw*.023f,vh*py-vh*.006f,180f,180f,true,paint)
        // UI overlay
        paint.textAlign=Paint.Align.CENTER
        paint.color=Color.rgb(245,231,255);paint.textSize=vw*.045f
        canvas.drawText("THE THINGS YOU LEFT BEHIND",vw*.5f,vh*.045f,paint)
        paint.color=Color.rgb(199,172,241);paint.textSize=vw*.025f
        canvas.drawText("A LITTLE WORLD MADE FOR ARCHA",vw*.5f,vh*.066f,paint)
        paint.textAlign=Paint.Align.LEFT;paint.color=Color.rgb(226,211,255);paint.textSize=vw*.03f
        canvas.drawText("MEMORIES: $foundCount / 4",vw*.05f,vh*.105f,paint)
        // Controls
        drawButton(canvas, upRect, "▲");drawButton(canvas, downRect, "▼");drawButton(canvas,leftRect,"◀");drawButton(canvas,rightRect,"▶")
        drawButton(canvas,interactRect,"LOOK\nAROUND",true)
        paint.textAlign=Paint.Align.CENTER;paint.color=Color.rgb(202,181,222);paint.textSize=vw*.026f
        canvas.drawText("Move with the arrows. Get close to a glow, then tap LOOK AROUND.",vw*.5f,vh*.965f,paint)
        if (dialog != null || showEnding) drawDialog(canvas)
        pulse += .08f
        if (dialog == null && !showEnding) { px=(px+dx*speed).coerceIn(.08f,.92f);py=(py+dy*speed).coerceIn(.12f,.93f) }
        postInvalidateDelayed(32)
    }

    private fun drawButton(c:Canvas,r:RectF,label:String,big:Boolean=false) {
        val alpha=Color.argb(205,35,20,55);paint.color=alpha; c.drawRoundRect(r,22f,22f,paint)
        paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=Color.argb(150,197,164,255);c.drawRoundRect(r,22f,22f,paint);paint.style=Paint.Style.FILL
        paint.color=Color.rgb(245,230,255);paint.textAlign=Paint.Align.CENTER;paint.textSize=if(big) vw*.025f else vw*.06f
        val lines=label.split("\n")
        lines.forEachIndexed { i,s -> c.drawText(s,r.centerX(),r.centerY()+(i-(lines.size-1)/2f)*paint.textSize*1.1f+paint.textSize*.35f,paint) }
    }
    private fun setupRects() {
        val size=vw*.12f; val y=vh*.82f
        leftRect.set(vw*.05f,y+size, vw*.05f+size,y+size*2)
        rightRect.set(vw*.05f+size*2+8,y+size,vw*.05f+size*3+8,y+size*2)
        upRect.set(vw*.05f+size+4,y, vw*.05f+size*2+4,y+size)
        downRect.set(vw*.05f+size+4,y+size*2+8, vw*.05f+size*2+4,y+size*3+8)
        interactRect.set(vw*.73f,vh*.84f,vw*.93f,vh*.94f)
    }
    override fun onSizeChanged(w:Int,h:Int,oldw:Int,oldh:Int){ super.onSizeChanged(w,h,oldw,oldh);vw=w.toFloat();vh=h.toFloat();setupRects() }
    override fun onTouchEvent(e:MotionEvent):Boolean {
        if (dialog != null || showEnding) {
            if(e.action==MotionEvent.ACTION_UP){dialog=null;if(showEnding){showEnding=false;memories.forEach{it.found=false};foundCount=0;px=.5f;py=.66f};invalidate()}
            return true
        }
        when(e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val x=e.x;val y=e.y
                dx=0f;dy=0f
                if(upRect.contains(x,y))dy=-1f
                if(downRect.contains(x,y))dy=1f
                if(leftRect.contains(x,y))dx=-1f
                if(rightRect.contains(x,y))dx=1f
                moveTouch=true
                if(interactRect.contains(x,y)) { dx=0f;dy=0f }
                invalidate();return true
            }
            MotionEvent.ACTION_UP -> {
                val x=e.x;val y=e.y
                if(interactRect.contains(x,y)) interact()
                dx=0f;dy=0f;moveTouch=false;invalidate();return true
            }
        }
        return true
    }
    private fun interact() {
        val nearby=memories.firstOrNull{!it.found && hypot((it.x-px).toDouble(),(it.y-py).toDouble())<.13}
        if(nearby!=null){nearby.found=true;foundCount++;dialog=nearby}
        else if(foundCount==4){showEnding=true}
        invalidate()
    }
    private fun drawDialog(c:Canvas) {
        paint.color=Color.argb(235,7,3,15);c.drawRect(0f,0f,vw,vh,paint)
        val box=RectF(vw*.07f,vh*.22f,vw*.93f,vh*.78f)
        paint.color=Color.rgb(28,16,44);c.drawRoundRect(box,28f,28f,paint)
        paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=Color.rgb(164,123,220);c.drawRoundRect(box,28f,28f,paint);paint.style=Paint.Style.FILL
        paint.textAlign=Paint.Align.CENTER;paint.color=Color.rgb(237,218,255);paint.textSize=vw*.052f
        val title=if(showEnding)"For you, Archa ♡" else dialog?.title.orEmpty()
        c.drawText(title,vw*.5f,box.top+vh*.08f,paint)
        val body=if(showEnding) "If I could give you a whole little world, I would fill it with every tiny thing that reminds me of you. The first hello, the first time I saw you, the canteen, the pen — and all the ordinary days that became precious because you were in them. You do not have to be perfect to be loved. I hope this little place reminds you that you are thought of, appreciated, and loved in all the small ways, too. Thank you for becoming my favourite part of the story. Happy birthday, my Archa. ♡" else dialog?.body.orEmpty()
        paint.textSize=vw*.034f;paint.color=Color.rgb(225,211,242)
        val words=body.split(" ");val lines=mutableListOf<String>();var line=""
        for(word in words){val test=if(line.isEmpty())word else "$line $word";if(paint.measureText(test)>vw*.75f){lines.add(line);line=word}else line=test};if(line.isNotEmpty())lines.add(line)
        val lineH=paint.textSize*1.55f;val maxLines= minOf(lines.size,11);val startY=box.centerY()-maxLines*lineH/2
        for(i in 0 until maxLines)c.drawText(lines[i],vw*.5f,startY+i*lineH,paint)
        paint.textSize=vw*.03f;paint.color=Color.rgb(195,163,242)
        c.drawText("TAP ANYWHERE TO CONTINUE",vw*.5f,box.bottom-vh*.055f,paint)
    }
}
