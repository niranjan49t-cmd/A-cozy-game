# Archa Purple Adventure 💜

A small native Android game project — not a website. It uses Android's Canvas API and Kotlin, with no third-party game engine or paid assets.

## What's in it
- Portrait Android app
- Purple moonlit garden
- On-screen movement buttons
- Four glowing memories: May 20 / first seeing each other / canteen / pen
- Personal ending after finding all four

## Build an APK for free with GitHub Actions
This source project has a workflow at `.github/workflows/build-apk.yml`.

1. Sign in to GitHub and create a **new public repository**.
2. Upload the contents of this ZIP into the repository (not the ZIP file itself). Keep the `.github/workflows/build-apk.yml` path intact.
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Press **Run workflow** (or wait for the first push build to finish).
5. Open the completed workflow run, scroll to **Artifacts**, and download `Archa-Purple-Adventure-APK`.
6. Extract that artifact ZIP to get `app-debug.apk`. Transfer it to the phone, open it, and allow installation from that source if Android asks.

The APK is a debug build, suitable for testing and sharing manually. It is not published to the Play Store. GitHub Actions usage limits and account requirements can change.

## Important
This is a simple first version, not a 3D Unreal-style game. It is a native Android app with a 2D illustrated exploration game. Build/signing is done by GitHub Actions; this environment cannot compile the APK directly.
